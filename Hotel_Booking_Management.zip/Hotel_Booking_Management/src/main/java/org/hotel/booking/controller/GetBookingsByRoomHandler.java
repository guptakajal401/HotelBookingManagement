package org.hotel.booking.controller;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.hotel.booking.service.BookingManagerService;

import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class GetBookingsByRoomHandler implements HttpHandler {
    private final BookingManagerService bookingManager;

    public GetBookingsByRoomHandler(BookingManagerService bookingManager) {
        this.bookingManager = bookingManager;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if ("GET".equals(exchange.getRequestMethod())) {
            String[] params = exchange.getRequestURI().getQuery().split("=");
            LocalDate date = LocalDate.parse(params[1], DateTimeFormatter.ISO_DATE);

            List<Integer> availableRooms = null;
            try {
                availableRooms = bookingManager.findAvailableRooms(date);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            String response = availableRooms.stream()
                    .map(String::valueOf)
                    .collect(Collectors.joining(", "));

            exchange.sendResponseHeaders(200, response.getBytes().length);
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        } else {
            exchange.sendResponseHeaders(405, -1); // Method Not Allowed
        }
    }
}
