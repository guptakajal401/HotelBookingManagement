package org.hotel.booking.controller;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.hotel.booking.dto.Booking;
import org.hotel.booking.service.BookingManagerService;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.stream.Collectors;

public class GetBookingsByGuestHandler implements HttpHandler {
    private final BookingManagerService bookingManager;

    public GetBookingsByGuestHandler(BookingManagerService bookingManager) {
        this.bookingManager = bookingManager;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if ("GET".equals(exchange.getRequestMethod())) {
            String[] params = exchange.getRequestURI().getQuery().split("=");
            String guestName = params[1];

            List<Booking> bookings = null;
            try {
                bookings = bookingManager.findBookingsByGuest(guestName);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            String response = bookings.stream()
                    .map(booking -> String.format("Room %d on %s", booking.getRoomNumber(), booking.getBookingDate()))
                    .collect(Collectors.joining(", "));

            exchange.sendResponseHeaders(200, response.getBytes().length);
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        } else {
            exchange.sendResponseHeaders(405, -1); // Method Not Allowed
        }
    }
}
