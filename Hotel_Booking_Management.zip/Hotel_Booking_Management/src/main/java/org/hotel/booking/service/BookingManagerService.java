package org.hotel.booking.service;

import org.hotel.booking.dto.Booking;

import java.time.LocalDate;
import java.util.List;

public interface BookingManagerService {

    void storeBooking(String guestName, int roomNumber, LocalDate bookingDate) throws Exception;
    List<Integer> findAvailableRooms(LocalDate date) throws Exception;
    List<Booking> findBookingsByGuest(String guestName) throws Exception;
}
