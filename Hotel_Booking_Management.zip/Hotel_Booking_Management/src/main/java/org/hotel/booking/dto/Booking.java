package org.hotel.booking.dto;

import java.time.LocalDate;

public class Booking {

    private String guestName;
    private int roomNumber;
    private LocalDate bookingDate;

    public Booking(String guestName, int roomNumber, LocalDate bookingDate) {
        this.guestName = guestName;
        this.roomNumber = roomNumber;
        this.bookingDate = bookingDate;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public String getGuestName() {
        return guestName;
    }
}
