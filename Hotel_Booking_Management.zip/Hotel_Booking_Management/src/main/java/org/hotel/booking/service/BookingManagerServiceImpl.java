package org.hotel.booking.service;

import org.hotel.booking.dto.Booking;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static java.util.List.copyOf;

public class BookingManagerServiceImpl implements BookingManagerService{

    private int numberOfRooms;
    private Map<Integer, List<Booking>> bookingsByRoom;
    private Map<String, List<Booking>> bookingsByGuest;

    public BookingManagerServiceImpl(int numberOfRooms) {
        this.numberOfRooms = numberOfRooms;
        this.bookingsByRoom = new ConcurrentHashMap<>();
        this.bookingsByGuest = new ConcurrentHashMap<>();
        for (int i = 1; i <= numberOfRooms; i++) {
            bookingsByRoom.put(i, new ArrayList<>());
        }
    }

    @Override
    public void storeBooking(String guestName, int roomNumber, LocalDate bookingDate) throws Exception {
        try {
            // Check if a booking already exists for the given room and date
            for (Booking booking : bookingsByRoom.get(roomNumber)) {
                if (booking.getBookingDate().equals(bookingDate)) {
                    throw new IllegalArgumentException("Booking already exists for room " + roomNumber + " on date " + bookingDate);
                }
            }

            Booking booking = new Booking(guestName, roomNumber, bookingDate);
            bookingsByRoom.get(roomNumber).add(booking);
            bookingsByGuest.computeIfAbsent(guestName, k -> new ArrayList<>()).add(booking);

        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to store booking: " + e.getMessage());
        }
    }

    @Override
    public List<Integer> findAvailableRooms(LocalDate date) throws Exception {
        List<Integer> availableRooms = new ArrayList<>();

        try {
            for (int i = 1; i <= numberOfRooms; i++) {
                boolean isBooked = false;
                for (Booking booking : bookingsByRoom.get(i)) {
                    if (booking.getBookingDate().equals(date)) {
                        isBooked = true;
                        break;
                    }
                }
                if (!isBooked) {
                    availableRooms.add(i);
                }
            }

            return copyOf(availableRooms);

        } catch (Exception e) {
            throw new IllegalArgumentException("Error finding available rooms: " + e.getMessage());
        }
    }

    @Override
    public List<Booking> findBookingsByGuest(String guestName) throws Exception {
        try {
            return copyOf(bookingsByGuest.getOrDefault(guestName, new ArrayList<>()));
        } catch (Exception e) {
            throw new IllegalArgumentException("Error finding bookings for guest: " + e.getMessage());
        }
    }
}
