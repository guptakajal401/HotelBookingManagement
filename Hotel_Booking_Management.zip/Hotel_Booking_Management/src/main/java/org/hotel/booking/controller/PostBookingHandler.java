package org.hotel.booking.controller;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.hotel.booking.service.BookingManagerService;

import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PostBookingHandler implements HttpHandler {
    private final BookingManagerService bookingManager;

    public PostBookingHandler(BookingManagerService bookingManager) {
        this.bookingManager = bookingManager;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if ("POST".equals(exchange.getRequestMethod())) {
            String[] params = exchange.getRequestURI().getQuery().split("&");
            String guestName = params[0].split("=")[1];
            int roomNumber = Integer.parseInt(params[1].split("=")[1]);
            LocalDate date = LocalDate.parse(params[2].split("=")[1], DateTimeFormatter.ISO_DATE);

            try {
                bookingManager.storeBooking(guestName, roomNumber, date);
                String response = "Booking stored successfully.";
                exchange.sendResponseHeaders(200, response.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            } catch (Exception e) {
                String response = "Error: " + e.getMessage();
                exchange.sendResponseHeaders(400, response.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            }
        } else {
            exchange.sendResponseHeaders(405, -1); // Method Not Allowed
        }
    }
}
