package org.hotel.booking.controller;

import com.sun.net.httpserver.HttpServer;
import org.hotel.booking.service.BookingManagerService;
import org.hotel.booking.service.BookingManagerServiceImpl;

import java.io.IOException;
import java.net.InetSocketAddress;

public class HotelBookingController {

    private static final int PORT = 8080;
    private final BookingManagerService bookingManager;

    public HotelBookingController(BookingManagerService bookingManager) throws IOException {
        this.bookingManager = bookingManager;
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/storeBooking", new PostBookingHandler(bookingManager));
        server.createContext("/findAvailableRooms", new GetBookingsByRoomHandler(bookingManager));
        server.createContext("/findBookingsByGuest", new GetBookingsByGuestHandler(bookingManager));
        server.setExecutor(null);
        server.start();
        System.out.println("Server started on port " + PORT);
    }

    public static void main(String[] args) throws IOException {
        BookingManagerService bookingManager = new BookingManagerServiceImpl(10);
        new HotelBookingController(bookingManager);
    }
}
